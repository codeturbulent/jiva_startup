window.addEventListener('scroll', () => {
  const header = document.querySelector('header');
  if (window.scrollY > 50) {  // Adjust scroll distance as needed
    header.classList.add('scrolled');
  } else {
    header.classList.remove('scrolled');
  }
});

someimportantstyles();

function setactive(element) {
  const activeElement = document.querySelector('.active');
  if (activeElement) {
    activeElement.classList.remove('active');
  }
  element.classList.add('active');
  
}